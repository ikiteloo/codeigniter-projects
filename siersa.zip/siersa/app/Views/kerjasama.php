<?= $this->extend('form_template'); ?>
<?= $this->section('content'); ?>
<div class="limiter">
    <div class="container-login100">
        <div class="login100-pic js-tilt" data-tilt style="padding-right: 40px;">
            <img src="https://siersa.umpp.ac.id/assets/img/logo_umpp.png" alt="IMG">
            <img src="https://siersa.umpp.ac.id/assets/img/slogan.png" alt="IMG" style="background-color: green; padding: 8px 8px 8px 8px; margin-top: 4px; border-radius: 8px;">
        </div>
        <br>
        <div class="wrap-login100">
            <form class="login100-form validate-form" enctype="multipart/form-data" action="<?= base_url('form/send') ?>" method="POST">
                <span class="login100-form-title">
                    Permohonan Perjanjian Kerjasama
                </span>
                <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Data Diri</strong></h5>
                <div class="wrap-input100 validate-input" style="margin-left: 7px" data-validate="Your name is required!">
                    <input class="input100" type="text" name="nama" id="nama" placeholder="Nama" autocomplete="off">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-id-card" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input">
                    <td>
                        <div class="wrap-input100 validate-input" data-validate="Your number is required!">
                            <input class="input100" style="margin-left: 8px;" type="text" name="wa" id="wa" onkeypress='validate(event)' placeholder="Contoh: 85601234567" autocomplete="off">
                            <span class="focus-input100"></span>
                            <span class="symbol-input100">
                                <i class="fa fa-phone" aria-hidden="true"></i>+62
                            </span>
                        </div>
                    </td>
                    <span style="font-size: 10px; color: red; padding-left: 20px;">*Nomor whatsapp tanpa awalan 0 / 62, Contoh: 85601234567</span>
                </div>

                <div class="wrap-input100 validate-input">
                    <select class="form-control" id="prodi" name="prodi" id="prodi">
                        <option value="( D3 ) AKUNTANSI">( D3 ) AKUNTANSI</option>
                        <option value="( D3 ) KEBIDANAN">( D3 ) KEBIDANAN</option>
                        <option value="( D3 ) KEPERAWATAN">( D3 ) KEPERAWATAN</option>
                        <option value="( D3 ) MANAJEMEN INFORMATIKA">( D3 ) MANAJEMEN INFORMATIKA</option>
                        <option value="( D3 ) TEKNIK ELEKTRONIKA">( D3 ) TEKNIK ELEKTRONIKA</option>
                        <option value="( D3 ) TEKNIK MESIN">( D3 ) TEKNIK MESIN</option>
                        <option value="( S1 ) AKUNTANSI">( S1 ) AKUNTANSI</option>
                        <option value="( S1 ) EKONOMI SYARIAH">( S1 ) EKONOMI SYARIAH</option>
                        <option value="( S1 ) FARMASI">( S1 ) FARMASI</option>
                        <option value="( S1 ) FISIOTERAPI">( S1 ) FISIOTERAPI</option>
                        <option value="( S1 ) INFORMATIKA">( S1 ) INFORMATIKA</option>
                        <option value="( S1 ) KEPERAWATAN">( S1 ) KEPERAWATAN</option>
                        <option value="( S1 ) MANAJEMEN">( S1 ) MANAJEMEN</option>
                        <option value="( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA">( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA</option>
                        <option value="( S1 ) PENDIDIKAN PROFESI BIDAN">( S1 ) PENDIDIKAN PROFESI BIDAN</option>
                        <option value="( S1 ) PROFESI NERS">( S1 ) PROFESI NERS</option>
                    </select>
                </div>
                <hr>

                <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Detail Instansi</strong></h5>
                <div class="wrap-input100 validate-input" data-validate="Destination agency is required!">
                    <input class="input100" type="text" name="intuj" id="intuj" placeholder="Instansi tujuan" autocomplete="off">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-building" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="The name of the head of the agency is required!">
                    <input class="input100" type="text" name="npintuj" id="npintuj" placeholder="Nama pemilik instansi tujuan" autocomplete="off">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Agency address required!">
                    <textarea style="height: 80px; padding-top: 2px; padding-bottom: 2px;" class="input100" type="text" name="alamat" id="alamat" placeholder="Alamat instansi tujuan" autocomplete="off"></textarea>
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </span>
                </div>
                <hr>

                <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Isi Kerjasama</strong></h5>
                <div class="wrap-input100 validate-input" data-validate="The title of cooperation is required!">
                    <input class="input100" type="text" name="juker" id="juker" placeholder="Judul kerjasama" autocomplete="off">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Cooperation objectives are needed!">
                    <textarea style="height: 150px; padding-top: 2px; padding-bottom: 2px;" class="input100" type="text" name="tuker" id="tuker" placeholder="Tujuan kerjasama" autocomplete="off"></textarea>
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-clipboard" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Scope of cooperation is required!">
                    <textarea style="height: 80px; padding-top: 2px; padding-bottom: 2px;" class="input100" type="text" name="ruli" id="ruli" placeholder="Ruang lingkup kerjasama" autocomplete="off"></textarea>
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-area-chart" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input">
                    <table>
                        <tr>
                            <td width="44%">
                                <div class="wrap-input100">
                                    <input class="input100" type="text" autocomplete="off" value="Jangka waktu" readonly>
                                    <span class="symbol-input100">
                                        <i class="fa fa-calendar-check-o" aria-hidden="true"></i>
                                    </span>
                                </div>
                            </td>
                            <td width="20%">
                                <div class="wrap-input100">
                                    <input class="input100" type="number" min="1" value="0" name="jawak" id="jawak">
                                    <span class="focus-input100"></span>
                                    <span class="symbol-input100">
                                        <i class="fa fa-sort-numeric-desc" aria-hidden="true"></i>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <div class="wrap-input100">
                                    <span style="padding-left: 8px;">tahun</span>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>

                <hr>
                <section>
                    <div class="container">
                        <div class="boxarea">
                            <div class="signature-pad" id="signature-pad">
                                <table width="100%">
                                    <tr>
                                        <td style="opacity: 0;"> - - </td>
                                        <td>
                                            <div class="m-signature-pad">
                                                <h6>Tanda tangan</h6>
                                                <div class="m-signature-pad-body">
                                                    <canvas></canvas>
                                                </div>
                                            </div>
                                        </td>
                                        <td style="opacity: 0;">
                                            <h5>Hasil</h5>
                                        </td>
                                        <td>
                                            <div class="container">
                                                <h6>Tersimpan</h6>
                                                <div class="boxarea">
                                                    <div id="previewsign1" class="previewsign">
                                                        <img src="#!" alt="TTD" id="ttdHidden" class="hidden">
                                                        <input type="hidden" name="B64IMG" value="" id="base64_img">
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <br>
                                            <div class="m-signature-pad-footer">
                                                <button type="button" data-action="clear" class="btn btn-danger"><i class="fa fa-trash-o"></i> Clear Signature</button>
                                                <button type="button" id="save2" data-action="save" class="btn btn-primary"><i class="fa fa-check"></i> Save</button>
                                            </div>
                                        </td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- random id generated here  -->
                <!-- <input type="hidden" value="<?= rand(1000000000, 9999999999) ?>" id="rowno" name="rowno"> -->
                <div class="container-login100-form-btn hidden">
                    <input class="login100-form-btn" type="submit" name="send" class="fadeIn fourth" value="Ajukan">
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>