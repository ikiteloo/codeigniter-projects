<?= $this->extend('form_template'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="pt-5">
        <div class="card card-body">
            <div class="text-center h1">
                <?php if ($type !== 'success') : ?>
                    <div class="pt-5 pb-5">
                        <div class="alert alert-danger" style="text-transform: capitalize;">
                            <?= $type; ?>
                        </div>
                        <p>Aplikasi yang anda maksud, gagal diajukan. !</p>
                    </div>
                <?php else : ?>
                    <div class="pt-5 pb-5">
                        <p class="text-muted h5">Token Permohonan Anda</p>
                        <code><?= $token ?></code>
                        <div class="mt-5">
                            <div class="alert alert-success">
                                <div class="h5">
                                    Permohonan yang anda maksud <strong>berhasil diajukan</strong>. !
                                </div>
                            </div>
                            <div class="p-2 bg-danger rounded">
                                <h6 class="text-white">Mohon ingat dan simpan token pengajuan anda.</h6>
                            </div>
                        </div>
                    </div>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>