<?= $this->extend('form_template'); ?>
<?= $this->section('content'); ?>
<div class="limiter">
    <div class="container-login100">
        <div class="login100-pic js-tilt" data-tilt style="padding-right: 40px;">
            <img src="https://siersa.umpp.ac.id/assets/img/logo_umpp.png" alt="IMG">
            <img src="https://siersa.umpp.ac.id/assets/img/slogan.png" alt="IMG" style="background-color: green; padding: 8px 8px 8px 8px; margin-top: 4px; border-radius: 8px;">
        </div>
        <br>
        <div class="wrap-login100">
            <div class="login100-form validate-form">
                <form action="<?= base_url('form/sendbm') ?>" enctype="multipart/form-data" method="post" id="bhs_mahasiswa" accept-charset="utf-8">
                    <span class="login100-form-title">Layanan Bahasa | Mahasiswa </span>

                    <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Data Diri</strong></h5>
                    <div class="wrap-input100 validate-input" data-validate="Your name is required!">
                        <input class="input100" type="text" name="nama" id="nama" placeholder="Nama Lengkap" autocomplete="off">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-id-card" aria-hidden="true"></i>
                        </span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Your id number (nim) is required!">
                        <input class="input100" type="text" name="nim" id="nim" placeholder="NIM" autocomplete="off">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-id-badge" aria-hidden="true"></i>
                        </span>
                    </div>

                    <div class="wrap-input100 validate-input">
                        <select class="form-control" id="prodi" name="prodi">
                            <option value="( D3 ) AKUNTANSI">( D3 ) AKUNTANSI</option>
                            <option value="( D3 ) KEBIDANAN">( D3 ) KEBIDANAN</option>
                            <option value="( D3 ) KEPERAWATAN">( D3 ) KEPERAWATAN</option>
                            <option value="( D3 ) MANAJEMEN INFORMATIKA">( D3 ) MANAJEMEN INFORMATIKA</option>
                            <option value="( D3 ) TEKNIK ELEKTRONIKA">( D3 ) TEKNIK ELEKTRONIKA</option>
                            <option value="( D3 ) TEKNIK MESIN">( D3 ) TEKNIK MESIN</option>
                            <option value="( S1 ) AKUNTANSI">( S1 ) AKUNTANSI</option>
                            <option value="( S1 ) EKONOMI SYARIAH">( S1 ) EKONOMI SYARIAH</option>
                            <option value="( S1 ) FARMASI">( S1 ) FARMASI</option>
                            <option value="( S1 ) FISIOTERAPI">( S1 ) FISIOTERAPI</option>
                            <option value="( S1 ) INFORMATIKA">( S1 ) INFORMATIKA</option>
                            <option value="( S1 ) KEPERAWATAN">( S1 ) KEPERAWATAN</option>
                            <option value="( S1 ) MANAJEMEN">( S1 ) MANAJEMEN</option>
                            <option value="( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA">( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA</option>
                            <option value="( S1 ) PENDIDIKAN PROFESI BIDAN">( S1 ) PENDIDIKAN PROFESI BIDAN</option>
                            <option value="( S1 ) PROFESI NERS">( S1 ) PROFESI NERS</option>
                        </select>
                    </div>

                    <div class="wrap-input100 validate-input">
                        <td>
                            <div class="wrap-input100 validate-input" data-validate="Your number is required!">
                                <input class="input100" style="margin-left: 8px;" type="text" name="wa" id="wa" onkeypress='validate(event)' placeholder="Contoh: 85601234567" maxlength="16" autocomplete="off">
                                <span class="focus-input100"></span>
                                <span class="symbol-input100">
                                    <i class="fa fa-phone" aria-hidden="true"></i>+62
                                </span>
                            </div>
                        </td>
                        <span style="font-size: 10px; color: red; padding-left: 20px;">*Nomor whatsapp tanpa awalan 0 / 62, Contoh: 85601234567</span>
                    </div>
                    <hr>

                    <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Pilih Penerjemahan</strong></h5>
                    <div class="wrap-input100 validate-input">
                        <select class="form-control" id="kdbhs" name="kdbhs">
                            <option value="A"> Indonesia -> English</option>
                            <option value="B"> English -> Indonesia</option>
                        </select>
                    </div>

                    <!-- <div class="wrap-input100 validate-input">
                        <select class="form-control" id="prodi" name="prodi" id="prodi">
                            <option value="0101">( D3 ) AKUNTANSI</option>
                            <option value="0202">( D3 ) KEBIDANAN</option>
                            <option value="0201">( D3 ) KEPERAWATAN</option>
                            <option value="0301">( D3 ) MANAJEMEN INFORMATIKA</option>
                            <option value="0302">( D3 ) TEKNIK ELEKTRONIKA</option>
                            <option value="0303">( D3 ) TEKNIK MESIN</option>
                            <option value="0102">( S1 ) AKUNTANSI</option>
                            <option value="0103">( S1 ) EKONOMI SYARIAH</option>
                            <option value="0206">( S1 ) FARMASI</option>
                            <option value="0205">( S1 ) FISIOTERAPI</option>
                            <option value="0304">( S1 ) INFORMATIKA</option>
                            <option value="0203">( S1 ) KEPERAWATAN</option>
                            <option value="0104">( S1 ) MANAJEMEN</option>
                            <option value="0207">( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA</option>
                            <option value="0208">( S1 ) PENDIDIKAN PROFESI BIDAN</option>
                            <option value="0204">( S1 ) PROFESI NERS</option>
                        </select>
                    </div> -->

                    <hr>
                    <h5 style="padding-left: 20px;padding-bottom: 4px;"><strong>Keterangan & File</strong></h5>
                    <div class="wrap-input100 validate-input" data-validate="The title of cooperation is required!">
                        <input class="input100" type="text" name="ket" id="ket" placeholder="Apa yang ingin diterjemahkan?" autocomplete="off" maxlength="20">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-ticket" aria-hidden="true"></i>
                        </span>
                    </div>
                    <div class="wrap-input100 validate-input">
                        <table>
                            <tr>
                                <td width="22%">
                                    <div class="wrap-input100">
                                        <input class="input100" type="text" autocomplete="off" value="Upload" readonly>
                                        <span class="symbol-input100">
                                            <i class="fa fa-paperclip" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="wrap-input100 validate-input" data-validate="Your number is required!">
                                        <input class="input100" style="padding-top: 11.5px;" type="file" name="upfile" id="upfile">
                                        <span class="focus-input100"></span>
                                        <span class="symbol-input100">
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <hr>
                    <section>
                        <div class="container">
                            <div class="boxarea">
                                <div class="signature-pad" id="signature-pad">
                                    <table width="100%">
                                        <tr>
                                            <td style="opacity: 0;"> - - </td>
                                            <td>
                                                <div class="m-signature-pad">
                                                    <h6>Tanda tangan</h6>
                                                    <div class="m-signature-pad-body">
                                                        <canvas></canvas>
                                                    </div>
                                                </div>
                                            </td>
                                            <td style="opacity: 0;">
                                                <h5>Hasil</h5>
                                            </td>
                                            <td>
                                                <div class="container">
                                                    <h6>Tersimpan</h6>
                                                    <div class="boxarea">
                                                        <div id="previewsign1" class="previewsign">
                                                            <img src="#!" alt="TTD" id="ttdHidden" class="hidden">
                                                            <input type="hidden" name="B64IMG" value="" id="base64_img">
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <br>
                                                <div class="m-signature-pad-footer">
                                                    <button type="button" data-action="clear" class="btn btn-danger"><i class="fa fa-trash-o"></i> Clear Signature</button>
                                                    <button type="button" id="save2" data-action="save" class="btn btn-primary"><i class="fa fa-check"></i> Save</button>
                                                </div>
                                            </td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- random id generated here  -->
                    <!-- <input type="hidden" value="random" id="rowno" name="rowno"> -->
                    <div class="container-login100-form-btn hidden">
                        <input class="login100-form-btn" type="submit" name="send" class="fadeIn fourth" value="Ajukan">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $("#bhs_mahasiswa").validate({
        rules: {
            upfile: {
                required: true,
                extension: "pdf|docx|doc|txt"
            }
        },
        messages: {
            upfile: {
                required: "Please upload your file",
                extension: "Please upload file with extension .pdf, .docx, .doc, .txt"
            }
        }
    });
</script>
<?= $this->endSection(); ?>