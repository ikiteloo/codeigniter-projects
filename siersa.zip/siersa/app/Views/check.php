<?= $this->extend('form_template'); ?>
<?= $this->section('content'); ?>
<div class="container py-5">
    <?php if (count($data['data']) > 1) : ?>
        <p>looping</p>
    <?php else : ?>
        <?php
        $datafix = $data['data'][0];
        ?>
        <div class="card card-body">
            <div class="px-5">
                <div class="text-center h2">
                    <code><?= $datafix['token'] ?></code>
                </div>
                <div class="mt-5"></div>

                <h5><strong>Data Diri</strong></h5>
                <table class="table table-hover table-borderless mt-2">
                    <tbody>
                        <tr>
                            <td width=50%>Token</td>
                            <td><strong><?= $datafix['token'] ?></strong></td>
                        </tr>
                        <tr>
                            <td width=50%>Status</td>
                            <td><strong class="text-primary"><?= $datafix['status'] ?></strong></td>
                        </tr>
                        <tr>
                            <td width=50%>Nama</td>
                            <td><strong><?= $datafix['nama'] ?></strong></td>
                        </tr>
                        <tr>
                            <td width=50%>Prodi</td>
                            <td><strong><?= $datafix['prodi'] ?></strong></td>
                        </tr>
                        <tr>
                            <td>WhatsApp</td>
                            <td><a href="https://wa.me/+62<?= $datafix['wa'] ?>" class="h6 text-success"><strong>+62<?= $datafix['wa'] ?></strong></a></td>
                        </tr>
                    </tbody>
                </table>
                <?php if ($data['type'] !== 'kerjasama') : ?>
                    <h5><strong>Detail</strong></h5>
                    <table class="table table-hover table-borderless mt-2">
                        <tbody>
                            <tr>
                                <td width=50%>Keterangan</td>
                                <td><strong><?= $datafix['ket'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Penerjemah</td>
                                <td>
                                    <strong>
                                        <?= $datafix['kdbhs'] == "A" ? "Indonesia <i class='fa fa-arrow-right px-2'></i> English" : "English <i class='fa fa-arrow-right px-2'></i> Indonesia"  ?>
                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                <td>File yang diajukan</td>
                                <td width=50%>
                                    <a class="h6" href="<?= base_url("uploads/" . $data['type'] . "/" . $datafix['file']) ?>"><?= $datafix['file'] ?></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                <?php else : ?>
                    <div class="mt-5"></div>
                    <h5><strong>Isi Kerjasama</strong></h5>
                    <table class="table table-hover table-borderless mt-2">
                        <tbody>
                            <tr>
                                <td width=50%>Instansi Tujuan</td>
                                <td><strong><?= $datafix['intuj'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Nama Pemilik Instansi Tujuan</td>
                                <td><strong><?= $datafix['npintuj'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Judul Kerjasama</td>
                                <td><strong><?= $datafix['juker'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Tujuan Kerjasama</td>
                                <td><strong><?= $datafix['tuker'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Ruang Lingkup Kerjasama</td>
                                <td><strong><?= $datafix['ruli'] ?></strong></td>
                            </tr>
                            <tr>
                                <td width=50%>Kangka Waktu</td>
                                <td><strong><?= $datafix['jawak'] ?> Tahun</strong></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif ?>
            </div>
        </div>
    <?php endif ?>
</div>
<?= $this->endSection(); ?>