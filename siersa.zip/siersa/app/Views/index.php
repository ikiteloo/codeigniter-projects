<!doctype html>
<html lang="en">

<head>
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>LPM | UMPP</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="https://siersa.umpp.ac.id/assets/img/logo_umpp.png" type="image/png">
    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="https://siersa.umpp.ac.id/assets/css/bootstrap.min.css">
    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="https://siersa.umpp.ac.id/assets/css/LineIcons.css">
    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="https://siersa.umpp.ac.id/assets/css/magnific-popup.css">
    <!--====== Default css ======-->
    <link rel="stylesheet" href="https://siersa.umpp.ac.id/assets/css/default.css">
    <!--====== Style css ======-->
    <link rel="stylesheet" href="https://siersa.umpp.ac.id/assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <script src="https://siersa.umpp.ac.id/assets/js/sweetalert2.all.min.js"></script>
</head>

<body>
    <!--====== HEADER PART START ======-->

    <div id="home" class="header-hero bg_cover" style="background-image: url(https://siersa.umpp.ac.id/assets/images/sky2.jpg); height: 180px;">
        <div class="header-shape">
            <img src="https://siersa.umpp.ac.id/assets/images/header-shape.svg" alt="shape">
        </div>
        <div class="header-shape">
            <img src="https://siersa.umpp.ac.id/assets/img/logo_umpp.png" style="height: 100px; width: auto; padding: 0px 80px 0px 0px; float: right;" alt="shape">
        </div>
    </div> <!-- header content -->
    </header>

    <!--====== HEADER PART ENDS ======-->

    <!--====== SERVICES PART START ======-->

    <section id="service" class="services-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-6">
                        <h4 class="title" style="font-weight: 500;">SIREK<strong>DOCK</strong></h4>
                        <p class="text">Sistem Informasi Pengajuan Kerjasama & Bahasa</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon mb-5">
                                    <i class="fa fa-bar-chart"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Kerjasama</h4>
                                    <!--<p class="text">Short description for the ones</br> who look for something new.</p>-->
                                    <ul class="header-btn">
                                        <li><a class="main-btn btn-one" href="<?= base_url('form/kerjasama') ?>">GET IN TOUCH</a></li>
                                    </ul>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon mb-5">
                                    <i class="fa fa-language"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Bahasa / Terjemah</h4>
                                    <!--<p class="text">Akta Lahir, Akta Nikah, Ijazah, Dll.</p>-->
                                </div>
                                <ul class="header-btn">
                                    <li><a class="main-btn btn-one" href="<?= base_url('form/bahasa') ?>">GET IN TOUCH</a></li>
                                </ul>
                            </div> <!-- services content -->
                        </div>
                    </div> <!-- row -->
                </div> <!-- row -->
            </div> <!-- row -->
        </div> <!-- conteiner -->
        <div class="services-image d-lg-flex align-items-center">
            <div class="image">
                <img src="https://siersa.umpp.ac.id/assets/img/rektorat.jpeg" alt="Services">
            </div>
        </div> <!-- services image -->
    </section>

    <!--====== jquery js ======-->
    <script src="https://siersa.umpp.ac.id/assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="https://siersa.umpp.ac.id/assets/js/bootstrap.min.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/popper.min.js"></script>

    <!--====== Scrolling Nav js ======-->
    <script src="https://siersa.umpp.ac.id/assets/js/jquery.easing.min.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/scrolling-nav.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="https://siersa.umpp.ac.id/assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Main js ======-->
    <script src="https://siersa.umpp.ac.id/assets/js/main.js"></script>

    <a href="javascript:void(0)" class="float2" onclick="Swal.mixin({
        input: 'password',
        confirmButtonText: 'Konfirmasi',
        progressSteps: ['!']
    }).queue([
    {
        title: 'ADMIN CONFIRMATION',
        text: 'Silahkan masukkan kode akses!'
    },
    ]).then((result) => {
        if(result.value){
            window.location.href = '<?= base_url('auth/u') ?>/' + result.value;
        }
    })">
        <i class="fa fa-user my-float2 fa-lg" style="padding-top: 6px;"></i>
    </a>
</body>

</html>