<?= $this->extend('admin/admin_template'); ?>
<?= $this->section('content'); ?>
<div class="card card-body shadow-sm">
    <div class="mb-4">
        <h3>Admin Dashboard</h3>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12 mb-3 col-xl-3">
            <div class="card card-body shadow text-center">
                <kbd>Kerjasama</kbd>
                <h1 class="display-3"><?= count($kerjasama) ?></h1>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12 mb-3 col-xl-3">
            <div class="card card-body shadow text-center">
                <kbd>Bahasa Mahasiswa</kbd>
                <h1 class="display-3"><?= count($bhs_mahasiswa) ?></h1>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12 mb-3 col-xl-3">
            <div class="card card-body shadow text-center">
                <kbd>Bahasa Dosen</kbd>
                <h1 class="display-3"><?= count($bhs_dosen) ?></h1>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12 mb-3 col-xl-3">
            <div class="card card-body shadow text-center">
                <kbd>Jumla Petugas</kbd>
                <h1 class="display-3"><?= count($user) ?></h1>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>