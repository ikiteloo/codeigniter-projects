<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Datatables -->
    <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <!-- JQuery -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

    <title>Admin</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= base_url('admin') ?>">SIREK<strong>DOCK</strong></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?= base_url() ?>">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php if (isset($_COOKIE['token'])) : ?>
                                <?= $_COOKIE['name'] ?>
                            <?php endif ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="/auth/out">Log Out</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row mt-4" style="height: 100vh;">
            <div class="col-md-3 mb-3">
                <ul class="list-group shadow-sm">
                    <a class="list-group-item <?= in_array('index', $segment) || count($segment) < 2 ? 'bg-success text-white' : 'text-dark' ?>" href="<?= base_url('admin/index') ?>">
                        <i class="fa fa-chart-line mr-2"></i>Dashboard
                    </a>
                    <a class="list-group-item <?= in_array('kerjasama', $segment) ? 'bg-success text-white' : 'text-dark' ?>" href="<?= base_url('admin/kerjasama') ?>">
                        <i class="fa-solid fa-handshake mr-2"></i>Kerjasama
                    </a>
                    <a class="list-group-item <?= in_array('bhsmhs', $segment) ? 'bg-success text-white' : 'text-dark' ?>" href="<?= base_url('admin/bhsmhs') ?>">
                        <i class="fa fa-language mr-2"></i>Bahasa ( <strong>Mahasiswa</strong> )
                    </a>
                    <a class="list-group-item <?= in_array('bhsdsn', $segment) ? 'bg-success text-white' : 'text-dark' ?>" href="<?= base_url('admin/bhsdsn') ?>">
                        <i class="fa fa-language mr-2"></i>Bahasa ( <strong>Dosen</strong> )
                    </a>
                    <a class="list-group-item <?= in_array('users', $segment) ? 'bg-success text-white' : 'text-dark' ?>" href="<?= base_url('admin/users') ?>">
                        <i class="fa fa-users mr-2"></i> Users
                    </a>
                </ul>
            </div>
            <div class="col-md-9 mb-3">
                <?= $this->renderSection('content'); ?>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    <!-- DataTables JS -->
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
</body>

</html>