<?= $this->extend('admin/admin_template'); ?>
<?= $this->section('content'); ?>
<?php if (isset($_GET['pesan'])) : ?>
    <?php if ($_GET['pesan'] == 'berhasil') : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berehasil !</strong> Perintah terakhir berhasil dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php elseif ($_GET['pesan'] == 'gagal') : ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Woops !</strong> Perintah terakhir gagal dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif ?>
<?php endif ?>

<div class="card card-body shadow-sm">
    <div class="table-responsive">
        <table class="table" id="tableBhsMhs">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Token</th>
                    <th>Status</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Terjemah</th>
                    <th>Bahasa</th>
                    <th class="text-center"><i class="fa fa-cogs"></i></th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($data as $d) : ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><small><kbd><?= $d['token'] ?></kbd></small></td>
                        <td><?= $d['status'] ?></td>
                        <td><?= $d['nama'] ?></td>
                        <td><?= $d['nim'] ?></td>
                        <td><?= $d['ket'] ?></td>
                        <td>
                            <small><kbd><?= $d['kdbhs'] == "A" ? "ID <i class='fa fa-arrow-right'></i> EN" : "EN <i class='fa fa-arrow-right'></i> ID"  ?></kbd></small>
                        </td>
                        <td class="text-center">
                            <small><button class="btn btn-sm btn-success btnDetail" data-token="<?= $d['token'] ?>" data-toggle="modal" data-target="#modalDetail"><i class="fa fa-search"></i></button></small>
                            <small><button class="btn btn-sm btn-light btnEdit" data-token="<?= $d['token'] ?>" data-toggle="modal" data-target="#modalEdit"><i class="fa fa-pen"></i></button></small>
                            <small><a href="/admin/bhsmhs_del/<?= $d['id'] ?>" onclick="return confirm('Aoakah anda yakin ingin menghapus data ini <?= $d['token'] ?> ?')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a></small>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Detail -->
<div class="modal fade" id="modalDetail" tabindex="-1" aria-labelledby="modalDetailLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalDetailLabel">Bahasa (MAHASISWA)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group mb-3">
                    <div class="row">
                        <div class="col">
                            <strong>
                                <h5 class="ml-2">Data Diri</h5>
                            </strong>
                            <table class="table table-hover table-borderless">
                                <tbody>
                                    <tr>
                                        <td width=40%>Token</td>
                                        <td id="token"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Status</td>
                                        <td id="status"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Nama</td>
                                        <td id="nama"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>NIM</td>
                                        <td id="nim"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Prodi</td>
                                        <td id="prodi"></td>
                                    </tr>
                                    <tr>
                                        <td>WhatsApp</td>
                                        <td id="wa"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col">
                            <h5><strong>Detail</strong></h5>
                            <table class="table table-hover table-borderless mt-2">
                                <tbody>
                                    <tr>
                                        <td width=50%>Keterangan</td>
                                        <td id="ket"></td>
                                    </tr>
                                    <tr>
                                        <td width=50%>Penerjemah</td>
                                        <td id="bhs"></td>
                                    </tr>
                                    <tr>
                                        <td width=50%>File yang diajukan</td>
                                        <td id="file"></td>
                                    </tr>
                                    <tr id="file_selesai_detail_tr">
                                        <td width=50%>File Selesai</td>
                                        <td id="file_selesai_detail"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEditLabel">Edit Data Kerjasama</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <strong>Perhatian!</strong>
                    <p>
                        Anda hanya bisa mengedit <strong>status pengajuan basaha & file balasan saja</strong> saja!.
                    </p>
                </div>
                <div class="form-group mb-3">
                    <form action="/admin/bhsmhs_update" enctype="multipart/form-data" method="post">
                        <input type="hidden" id="randomEdit" name="randomEdit">
                        <div class="row">
                            <div class="col">
                                <strong>
                                    <h5 class="ml-2">Data Diri</h5>
                                </strong>
                                <table class="table table-hover table-borderless">
                                    <tbody>
                                        <tr>
                                            <td width=40%>Token</td>
                                            <td><input type="number" class="form-control" readonly name="token" id="input_token"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Status</td>
                                            <td>
                                                <select class="form-control pilihstatus" id="status" name="status" id="status">
                                                    <option value="PROSES">PROSES</option>
                                                    <option value="ACCEPTED">ACCEPTED</option>
                                                    <option value="REJECTED">REJECTED</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Nama</td>
                                            <td><input type="text" readonly class="form-control" name="nama" id="input_nama"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>NIM</td>
                                            <td><input type="text" readonly class="form-control" name="nim" id="input_nim"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Prodi</td>
                                            <td>
                                                <select class="form-control pilihprodi" disabled id="prodi" name="prodi" id="prodi">
                                                    <option value="( D3 ) AKUNTANSI">( D3 ) AKUNTANSI</option>
                                                    <option value="( D3 ) KEBIDANAN">( D3 ) KEBIDANAN</option>
                                                    <option value="( D3 ) KEPERAWATAN">( D3 ) KEPERAWATAN</option>
                                                    <option value="( D3 ) MANAJEMEN INFORMATIKA">( D3 ) MANAJEMEN INFORMATIKA</option>
                                                    <option value="( D3 ) TEKNIK ELEKTRONIKA">( D3 ) TEKNIK ELEKTRONIKA</option>
                                                    <option value="( D3 ) TEKNIK MESIN">( D3 ) TEKNIK MESIN</option>
                                                    <option value="( S1 ) AKUNTANSI">( S1 ) AKUNTANSI</option>
                                                    <option value="( S1 ) EKONOMI SYARIAH">( S1 ) EKONOMI SYARIAH</option>
                                                    <option value="( S1 ) FARMASI">( S1 ) FARMASI</option>
                                                    <option value="( S1 ) FISIOTERAPI">( S1 ) FISIOTERAPI</option>
                                                    <option value="( S1 ) INFORMATIKA">( S1 ) INFORMATIKA</option>
                                                    <option value="( S1 ) KEPERAWATAN">( S1 ) KEPERAWATAN</option>
                                                    <option value="( S1 ) MANAJEMEN">( S1 ) MANAJEMEN</option>
                                                    <option value="( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA">( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA</option>
                                                    <option value="( S1 ) PENDIDIKAN PROFESI BIDAN">( S1 ) PENDIDIKAN PROFESI BIDAN</option>
                                                    <option value="( S1 ) PROFESI NERS">( S1 ) PROFESI NERS</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>WhatsApp</td>
                                            <td><input type="number" readonly class="form-control" name="wa" id="input_wa"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col">
                                <h5><strong>Detail</strong></h5>
                                <table class="table table-hover table-borderless mt-2">
                                    <tbody>
                                        <tr>
                                            <td width=40%>Keterangan</td>
                                            <td><input type="text" name="ket" id="kinput_ket" readonly class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Penerjemah</td>
                                            <td><input type="text" name="bhs" id="binput_bhs" readonly class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>File yang diajukan</td>
                                            <td id="file_diajukan"></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="mt-3">
                                    <h5><strong>Selesai</strong></h5>
                                    <table class="table table-hover table-borderless mt-2">
                                        <tbody>
                                            <tr>
                                                <td width=40%>File Selesai</td>
                                                <td>
                                                    <div class="form-group" id="fieldFileSelesai">
                                                        <label class="custom-file-label" for="customFile">Choose file</label>
                                                        <input type="file" name="file_selesai"  class="form-control-file" id="customFile">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width=40%>Download</td>
                                                <td id="file_selesainya"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <button type="submit" class="btn btn-success">SIMPAN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tableBhsMhs').DataTable();
        $(".alertClose").click(function(params) {
            var clean_uri = location.protocol + "//" + location.host + location.pathname;
            window.history.replaceState({}, document.title, clean_uri);

        });
        $(".btnDetail").each(function() {
            $(this).click(function() {
                var token = $(this).data('token');
                $.ajax({
                    url: "<?= base_url('admin/get') ?>/" + token,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $("#token").html(`<strong>${data.data[0].token}</strong>`);
                        $("#status").html(`<strong>${data.data[0].status}</strong>`);
                        $("#nama").html(`<strong>${data.data[0].nama}</strong>`);
                        $("#nim").html(`<strong>${data.data[0].nim}</strong>`);
                        $("#prodi").html(`<strong>${data.data[0].prodi}</strong>`);
                        $("#wa").html(`<a href="https://wa.me/+62${data.data[0].wa}" target="_blank" class="h6 text-success"><strong>0${data.data[0].wa}</strong></a>`);
                        if (data.type == 'bhs_mahasiswa') {
                            $("#ket").html(`<strong>${data.data[0].ket}</strong>`);
                            $("#bhs").html(data.data[0].kdbhs == "A" ? `<strong>ID <i class="fa fa-arrow-right"></i> EN</strong>` : `<strong>EN <i class="fa fa-arrow-right"></i> ID</strong>`);
                            $("#file").html(`<a href="<?= base_url('uploads') ?>/${data.type}/${data.data[0].file}">${data.data[0].file}</a>`);

                            if (data.data[0].status == "ACCEPTED") {
                                $("#file_selesai_detail_tr").show();
                                $("#file_selesai_detail").html(`<a href="<?= base_url('uploads') ?>/${data.type}/${data.data[0].file_selesai}">${data.data[0].file_selesai}</a>`);
                            } else {
                                $("#file_selesai_detail_tr").hide();   
                            }
                        }
                    }
                });
            });
        });
        $(".btnEdit").each(function() {
            $(this).click(function() {
                var token = $(this).data('token');
                $.ajax({
                    url: "<?= base_url('admin/get') ?>/" + token,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        console.log(data.data[0].status);
                        $("#randomEdit").val(data.data[0].id);
                        $("#input_token").val(data.data[0].token);
                        $("#input_nama").val(data.data[0].nama);
                        $("#input_nim").val(data.data[0].nim);
                        $("#input_wa").val(data.data[0].wa);
                        $('.pilihstatus option[value="' + data.data[0].status + '"]').attr('selected', 'selected');
                        $('.pilihprodi option[value="' + data.data[0].prodi + '"]').attr('selected', 'selected');

                        if (data.type == 'bhs_mahasiswa') {
                            $("#kinput_ket").val(data.data[0].ket);
                            $("#input_bhs").val(data.data[0].kdbhs == "A" ? `<strong>ID <i class="fa fa-arrow-right"></i> EN</strong>` : `<strong>EN <i class="fa fa-arrow-right"></i> ID</strong>`);
                            $("#file_diajukan").html(`<a href="<?= base_url('uploads') ?>/${data.type}/${data.data[0].file}">${data.data[0].file}</a>`);
                            if (data.data[0].status == "ACCEPTED") {
                                $("#file_selesainya").html(`<a href="<?= base_url('uploads') ?>/${data.type}/${data.data[0].file_selesai}">${data.data[0].file_selesai}</a>`);
                            } else {
                                $("#file_selesainya").html("");
                            }
                        }


                        $("#fieldFileSelesai").hide();
                        $(".pilihstatus").on('change', function() {
                            var status = $(this).val();
                            if (status == 'ACCEPTED') {
                                $("#fieldFileSelesai").show();
                            } else {
                                $("#fieldFileSelesai").hide();
                            }
                        });
                    }
                });
            });
        });
    });
</script>
<?= $this->endSection(); ?>