<?= $this->extend('admin/admin_template'); ?>
<?= $this->section('content'); ?>
<?php if (isset($_GET['pesan'])) : ?>
    <?php if ($_GET['pesan'] == 'berhasil') : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berehasil !</strong> Perintah terakhir berhasil dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php elseif ($_GET['pesan'] == 'gagal') : ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Woops !</strong> Perintah terakhir gagal dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif ?>
<?php endif ?>

<div class="card card-body shadow-sm">
    <div id="atas" class="d-flex justify-content-between align-items-center">
        <h3>Daftar User</h3>
        <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#addUserModal"><i class="fa fa-plus"></i> Tambah User</button>
    </div>
    <div class="mt-4">
        <table class="table" id="tableUser">
            <thead>
                <tr>
                    <th width=50>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Token</th>
                    <th width=70 class="text-center"><i class="fa fa-cogs"></i></th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($users as $user) : ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $user['name']; ?></td>
                        <td><?= $user['email']; ?></td>
                        <td><kbd><?= $user['token']; ?></kbd></td>
                        <td>
                            <a href="<?= base_url('admin/users/edit/' . $user['id']); ?>" class="btn btn-sm btn-light btnEdit" data-token="<?= $user['token'] ?>" data-toggle="modal" data-target="#modalEdit"><i class="fa fa-pen"></i></a>
                            <a href="<?= base_url('admin/user_del/' . $user['id']); ?>" onclick="return confirm('yakin akan menghapus user : <?= $user['name'] ?>')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Add User -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/user_add" method="post">
                    <div class="form-group">
                        <div class="form-labe">Nama</div>
                        <input type="text" name="nama" id="nama" class="form-control">
                    </div>
                    <div class="form-group">
                        <div class="form-labe">Email</div>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit User -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEditLabel">Update User Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/user_update" method="post">
                    <input type="hidden" name="randomEdit">
                    <div class="form-group">
                        <div class="form-labe">Token</div>
                        <input type="text" name="token" readonly id="input_token" class="form-control">
                    </div>
                    <div class="form-group">
                        <div class="form-labe">Nama</div>
                        <input type="text" name="nama" id="input_nama" class="form-control">
                    </div>
                    <div class="form-group">
                        <div class="form-labe">Email</div>
                        <input type="email" name="email" id="input_email" class="form-control">
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tableUser').DataTable();

        $(".alertClose").click(function(params) {
            var clean_uri = location.protocol + "//" + location.host + location.pathname;
            window.history.replaceState({}, document.title, clean_uri);

        });

        $(".btnEdit").each(function() {
            $(this).click(function() {
                var token = $(this).data('token');
                $.ajax({
                    url: "<?= base_url('admin/get_user') ?>/" + token,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $("[name=randomEdit]").val(data.id);
                        $("#input_token").val(data.token);
                        $("#input_nama").val(data.name);
                        $("#input_email").val(data.email);
                    }
                });
            });
        });
    });
</script>
<?= $this->endSection(); ?>