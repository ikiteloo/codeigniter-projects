<?= $this->extend('admin/admin_template'); ?>
<?= $this->section('content'); ?>

<?php if (isset($_GET['pesan'])) : ?>
    <?php if ($_GET['pesan'] == 'berhasil') : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berehasil !</strong> Perintah terakhir berhasil dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php elseif ($_GET['pesan'] == 'gagal') : ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Woops !</strong> Perintah terakhir gagal dijalankan.
            <button type="button" class="close alertClose" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif ?>
<?php endif ?>

<div class="card card-body shadow-sm">
    <h3>Daftar Pengajuan Kerjasama</h3>
    <div class="mt-4 table-responsive">
        <table class="table" id="tabelKerjasama">
            <thead>
                <tr>
                    <th><i class="fa fa-hashtag"></i></th>
                    <th>Token</th>
                    <th><i class="fa fa-hashtag"></i></th>
                    <th>Judul</th>
                    <th>Asal</th>
                    <th>Waktu</th>
                    <th class="text-center"><i class="fa fa-cogs"></i></th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($data as $d) : ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><small><kbd><?= $d['token'] ?></kbd></small></td>
                        <td>
                            <?php if ($d['status'] == "PROSES") : ?>
                                <span data-toggle="tooltip" data-placement="top" title="<?= $d['status'] ?>">
                                    <i class="fa fa-arrows-rotate text-primary"></i>
                                </span>
                            <?php elseif ($d['status'] == "ACCEPTED") : ?>
                                <span data-toggle="tooltip" data-placement="top" title="<?= $d['status'] ?>">
                                    <i class="fa fa-circle-check text-success"></i>
                                </span>
                            <?php else : ?>
                                <span data-toggle="tooltip" data-placement="top" title="<?= $d['status'] ?>">
                                    <i class="fa fa-circle-xmark text-danger"></i>
                                </span>
                            <?php endif ?>
                        </td>
                        <td><?= $d['juker'] ?></td>
                        <td><?= $d['intuj'] ?></td>
                        <td><?= $d['jawak'] ?> Thn</td>
                        <td>
                            <small><button class="btn btn-sm btn-success btnDetail" data-token="<?= $d['token'] ?>" data-toggle="modal" data-target="#modalDetail"><i class="fa fa-search"></i></button></small>
                            <small><button class="btn btn-sm btn-light btnEdit" data-token="<?= $d['token'] ?>" data-toggle="modal" data-target="#modalEdit"><i class="fa fa-pen"></i></button></small>
                            <small><a href="/admin/kerjasama_del/<?= $d['id'] ?>" onclick="return confirm('Aoakah anda yakin ingin menghapus data ini <?= $d['token'] ?> ?')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a></small>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Detail -->
<div class="modal fade" id="modalDetail" tabindex="-1" aria-labelledby="modalDetailLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalDetailLabel">Detail Kerjasama</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group mb-3">
                    <div class="row">
                        <div class="col">
                            <strong>
                                <h5 class="ml-2">Data Diri</h5>
                            </strong>
                            <table class="table table-hover table-borderless">
                                <tbody>
                                    <tr>
                                        <td width=40%>Token</td>
                                        <td id="token"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Status</td>
                                        <td id="status"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Nama</td>
                                        <td id="nama"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Prodi</td>
                                        <td id="prodi"></td>
                                    </tr>
                                    <tr>
                                        <td>WhatsApp</td>
                                        <td id="wa"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col">
                            <strong>
                                <h5 class="ml-2">Isi Kerjasama</h5>
                            </strong>
                            <table class="table table-hover table-borderless">
                                <tbody>
                                    <tr>
                                        <td width=40%>Instansi Tujuan</td>
                                        <td id="intuj"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Nama Pemilik Instansi Tujuan</td>
                                        <td id="npintuj"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Judul Kerjasama</td>
                                        <td id="juker"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Tujuan Kerjasama</td>
                                        <td id="tuker"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Ruang Lingkup Kerjasama</td>
                                        <td id="ruli"></td>
                                    </tr>
                                    <tr>
                                        <td width=40%>Kangka Waktu</td>
                                        <td id="jawak"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="mb-3">
                        <strong>
                            <h5 class="ml-2">TTD</h5>
                        </strong>
                        <div class="ml-2 ttdnya"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEditLabel">Edit Data Kerjasama</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <strong>Perhatian!</strong>
                    <p>
                        Anda hanya bisa mengedit <strong>status kerjasama</strong> saja!.
                    </p>
                </div>
                <div class="form-group mb-3">
                    <form action="/admin/kerjasama_update" method="post">
                        <input type="hidden" id="randomEdit" name="randomEdit">
                        <div class="row">
                            <div class="col">
                                <strong>
                                    <h5 class="ml-2">Data Diri</h5>
                                </strong>
                                <table class="table table-hover table-borderless">
                                    <tbody>
                                        <tr>
                                            <td width=40%>Token</td>
                                            <td><input type="number" class="form-control" readonly name="token" id="input_token"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Status</td>
                                            <td>
                                                <select class="form-control pilihstatus" id="status" name="status" id="status">
                                                    <option value="PROSES">PROSES</option>
                                                    <option value="ACCEPTED">ACCEPTED</option>
                                                    <option value="REJECTED">REJECTED</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Nama</td>
                                            <td><input type="text" readonly class="form-control" name="nama" id="input_nama"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Prodi</td>
                                            <td>
                                                <select class="form-control pilihprodi" disabled id="prodi" name="prodi" id="prodi">
                                                    <option value="( D3 ) AKUNTANSI">( D3 ) AKUNTANSI</option>
                                                    <option value="( D3 ) KEBIDANAN">( D3 ) KEBIDANAN</option>
                                                    <option value="( D3 ) KEPERAWATAN">( D3 ) KEPERAWATAN</option>
                                                    <option value="( D3 ) MANAJEMEN INFORMATIKA">( D3 ) MANAJEMEN INFORMATIKA</option>
                                                    <option value="( D3 ) TEKNIK ELEKTRONIKA">( D3 ) TEKNIK ELEKTRONIKA</option>
                                                    <option value="( D3 ) TEKNIK MESIN">( D3 ) TEKNIK MESIN</option>
                                                    <option value="( S1 ) AKUNTANSI">( S1 ) AKUNTANSI</option>
                                                    <option value="( S1 ) EKONOMI SYARIAH">( S1 ) EKONOMI SYARIAH</option>
                                                    <option value="( S1 ) FARMASI">( S1 ) FARMASI</option>
                                                    <option value="( S1 ) FISIOTERAPI">( S1 ) FISIOTERAPI</option>
                                                    <option value="( S1 ) INFORMATIKA">( S1 ) INFORMATIKA</option>
                                                    <option value="( S1 ) KEPERAWATAN">( S1 ) KEPERAWATAN</option>
                                                    <option value="( S1 ) MANAJEMEN">( S1 ) MANAJEMEN</option>
                                                    <option value="( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA">( S1 ) PENDIDIKAN JASMANI DAN OLAHRAGA</option>
                                                    <option value="( S1 ) PENDIDIKAN PROFESI BIDAN">( S1 ) PENDIDIKAN PROFESI BIDAN</option>
                                                    <option value="( S1 ) PROFESI NERS">( S1 ) PROFESI NERS</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>WhatsApp</td>
                                            <td><input type="number" readonly class="form-control" name="wa" id="input_wa"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col">
                                <strong>
                                    <h5 class="ml-2">Isi Kerjasama</h5>
                                </strong>
                                <table class="table table-hover table-borderless">
                                    <tbody>
                                        <tr>
                                            <td width=40%>Instansi Tujuan</td>
                                            <td><input type="text" readonly name="intuj" id="input_intuj" class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Nama Pemilik Instansi Tujuan</td>
                                            <td><input type="text" readonly name="npintuj" id="input_npintuj" class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Judul Kerjasama</td>
                                            <td><input type="text" readonly name="juker" id="input_juker" class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Tujuan Kerjasama</td>
                                            <td><input type="text" readonly name="tuker" id="input_tuker" class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Ruang Lingkup Kerjasama</td>
                                            <td><input type="text" readonly name="ruli" id="input_ruli" class="form-control"></td>
                                        </tr>
                                        <tr>
                                            <td width=40%>Kangka Waktu</td>
                                            <td><input type="text" readonly name="jawak" id="input_jawak" class="form-control"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="mt-4">
                            <button type="submit" class="btn btn-success">SIMPAN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<script>
    $(document).ready(function() {
        // DataTables
        $('#tabelKerjasama').DataTable();
        // Detail Kerjasama
        $(".btnDetail").each(function() {
            $(this).click(function() {
                var token = $(this).data('token');
                $.ajax({
                    url: "<?= base_url('admin/get') ?>/" + token,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $("#token").html(`<strong>${data.data[0].token}</strong>`);
                        $("#status").html(`<strong>${data.data[0].status}</strong>`);
                        $("#nama").html(`<strong>${data.data[0].nama}</strong>`);
                        $("#prodi").html(`<strong>${data.data[0].prodi}</strong>`);
                        $("#wa").html(`<a href="https://wa.me/+62${data.data[0].wa}" target="_blank" class="h6 text-success"><strong>0${data.data[0].wa}</strong></a>`);
                        if (data.type == 'kerjasama') {
                            $("#intuj").html(`<strong>${data.data[0].intuj}</strong>`);
                            $("#npintuj").html(`<strong>${data.data[0].npintuj}</strong>`);
                            $("#juker").html(`<strong>${data.data[0].juker}</strong>`);
                            $("#tuker").html(`<strong>${data.data[0].tuker}</strong>`);
                            $("#ruli").html(`<strong>${data.data[0].ruli}</strong>`);
                            $("#jawak").html(`<strong>${data.data[0].jawak} Tahun</strong>`);
                            // ttdnya
                            $(".ttdnya").html(`<img src="${data.data[0].B64IMG}" alt="${data.data[0].nama}" class="img-fluid">`);
                        }
                    }
                });
            });
        });
        // Edit Kerjasama
        $(".btnEdit").each(function() {
            $(this).click(function() {
                var token = $(this).data('token');
                $.ajax({
                    url: "<?= base_url('admin/get') ?>/" + token,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        $("#randomEdit").val(data.data[0].id);
                        $("#input_token").val(data.data[0].token);
                        $("#input_nama").val(data.data[0].nama);
                        $("#input_wa").val(data.data[0].wa);
                        $('.pilihstatus option[value="' + data.data[0].status + '"]').attr('selected', 'selected');
                        $('.pilihprodi option[value="' + data.data[0].prodi + '"]').attr('selected', 'selected')
                        if (data.type == 'kerjasama') {
                            $("#input_intuj").val(data.data[0].intuj);
                            $("#input_npintuj").val(data.data[0].npintuj);
                            $("#input_juker").val(data.data[0].juker);
                            $("#input_tuker").val(data.data[0].tuker);
                            $("#input_ruli").val(data.data[0].ruli);
                            $("#input_jawak").val(data.data[0].jawak);
                        }
                    }
                });
            });
        });
        // Alert Close
        $(".alertClose").click(function(params) {
            var clean_uri = location.protocol + "//" + location.host + location.pathname;
            window.history.replaceState({}, document.title, clean_uri);

        });
    });
</script>
<?= $this->endSection(); ?>