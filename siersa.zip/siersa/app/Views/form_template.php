<!DOCTYPE html>
<html lang="en">

<head>
    <title>Permohonan Perjanjian Kerjasama</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="https://siersa.umpp.ac.id/assets/img/logo_umpp.png" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/css/util.css">
    <link rel="stylesheet" type="text/css" href="https://siersa.umpp.ac.id/assets/css/main.css">
    <!--===============================================================================================-->

    <script src="https://siersa.umpp.ac.id/assets/vendor/jquery/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/additional-methods.min.js"></script>

    <style>
        .m-signature-pad-body {
            border: 1px dashed #ccc;
            border-radius: 5px;
            color: #bbbabb;
            height: 150px;
            width: 300px;
            text-align: center;
            vertical-align: middle;
        }

        .previewsign {
            border: 1px dashed #ccc;
            border-radius: 5px;
            color: #bbbabb;
            height: 150px;
            width: 300px;
            text-align: center;
            vertical-align: middle;
        }

        .hidden {
            display: none;
        }
    </style>
    <!--===============================================================================================-->
</head>

<body>

    <?= $this->renderSection('content'); ?>

    <!--===============================================================================================-->
    <script src="https://siersa.umpp.ac.id/assets/vendor/bootstrap/js/popper.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="https://siersa.umpp.ac.id/assets/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="https://siersa.umpp.ac.id/assets/vendor/tilt/tilt.jquery.min.js"></script>
    <script>
        $('.js-tilt').tilt({
            scale: 1.1
        })
    </script>
    <!--===============================================================================================-->
    <script src="https://siersa.umpp.ac.id/assets/js/main.js"></script>
    <!--===============================================================================================-->
    <script src="https://siersa.umpp.ac.id/assets/js/sweetalert2.all.min.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/jquery-2.1.3.min.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/signature-pad.js"></script>
    <script src="https://siersa.umpp.ac.id/assets/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Warning!</h4>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger">
                        Sign before you submit!
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<div style="position: relative; z-index: 1000;">
    <a href="<?= base_url() ?>" class="float1">
        <i class="fa fa-home my-float1"></i>
    </a>
    <button style="border: none;" onclick="Swal.mixin({
            input: 'text',
            confirmButtonText: 'Cek',
            showCancelButton: true,
            cancelButtonText:'Batal',
            progressSteps: ['C']
            }).queue([
            {
                title: 'Cek Status Form',
                text: 'Silahkan masukkan token form anda!'
            },
            ]).then((result) => {
            if (result.value == false) {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong! Input your token!',
                })
                return false;
            }
            if (result.value){
                window.location.href = '<?= base_url('pages/check'). '/' ?>'+result.value;
            }
            })" class="float2">
        <i class="fa fa-print fa-2x"></i>
    </button>
</div>
<script>

    function validate(evt) {
        var theEvent = evt || window.event;

        // Handle paste
        if (theEvent.type === 'paste') {
            key = event.clipboardData.getData('text/plain');
        } else {
            // Handle key press
            var key = theEvent.keyCode || theEvent.which;
            key = String.fromCharCode(key);
        }
        var regex = /[0-9]|\./;
        if (!regex.test(key)) {
            theEvent.returnValue = false;
            if (theEvent.preventDefault) theEvent.preventDefault();
        }
    }


    //Signature
    var wrapper = document.getElementById("signature-pad"),
        clearButton = wrapper.querySelector("[data-action=clear]"),
        saveButton = wrapper.querySelector("[data-action=save]"),
        canvas = wrapper.querySelector("canvas"),
        signaturePad;


    function resizeCanvas() {
        var ratio = window.devicePixelRatio || 1;
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        canvas.getContext("2d").scale(ratio, ratio);
    }
    signaturePad = new SignaturePad(canvas);

    clearButton.addEventListener("click", function(event) {
        signaturePad.clear();
    });

    saveButton.addEventListener("click", function(event) {

        if (signaturePad.isEmpty()) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Silahkan isi tanda tangan terlebih dahulu!',
            })
        } else {
            var hidden = document.getElementsByClassName("hidden");

            for (i = 0; i < hidden.length; i++) {
                hidden[i].style.display = "block";
            }

            $("#ttdHidden").removeClass('hidden');
            $('#ttdHidden').attr('src', signaturePad.toDataURL());
            $('#base64_img').val(signaturePad.toDataURL());


            // $.ajax({
            //     type: "POST",
            //     url: "https://siersa.umpp.ac.id/Form/insert_single_signature",
            //     data: {
            //         'image': signaturePad.toDataURL(),
            //         'rowno': $('#rowno').val(),
            //         'nama': $('#nama').val()
            //     },
            //     success: function(datas1) {
            //         signaturePad.clear();
            //         $('.previewsign').html(datas1);
            //     }
            // });
            /*
            $.ajax({
                type: "POST",
                url: "https://siersa.umpp.ac.id/Form/send",
                data: {
                    'nama': $('#nama').val(),
                    'wa': $('#wa').val(),
                    'prodi': $('#prodi').val(),
                    'intuj': $('#intuj').val(),
                    'npintuj': $('#npintuj').val(),
                    'alamat': $('#alamat').val(),
                    'juker': $('#juker').val(),
                    'tuker': $('#tuker').val(),
                    'ruli': $('#ruli').val(),
                    'jawak': $('#jawak').val(),
                    'rowno': $('#rowno').val()
                },
            });
            */
        }
    });
</script>

</html>