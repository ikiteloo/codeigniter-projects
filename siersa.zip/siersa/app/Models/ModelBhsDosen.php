<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelBhsDosen extends Model
{
    protected $table            = 'bhs_dosen';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 53498;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['token', 'file', 'file_selesai', 'status', 'nama', 'prodi', 'wa', 'kdbhs', 'ket', 'B64IMG',];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
}
