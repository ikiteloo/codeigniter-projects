<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelKerjasama extends Model
{
    protected $table            = 'kerjasama';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 74389;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = ['token', 'nama', 'wa', 'status', 'prodi', 'intuj', 'npintuj', 'alamat', 'juker', 'tuker', 'ruli', 'jawak', 'B64IMG'];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
}
