<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ModelBhsDosen;
use App\Models\ModelKerjasama;
use App\Models\ModelBhsMahasiswa;

class Pages extends BaseController
{
    protected $kerjasama;
    protected $bhs_mahasiswa;
    protected $bhs_dosen;

    public function __construct()
    {
        $this->kerjasama = new ModelKerjasama();
        $this->bhs_mahasiswa = new ModelBhsMahasiswa();
        $this->bhs_dosen = new ModelBhsDosen();
    }

    public function index()
    {
        return redirect()->to(base_url());
    }

    public function check($token)
    {
        $data = null;

        if ($this->kerjasama->where('token', $token)->find()) {
            $data = [
                'type' => "kerjasama",
                'data' => $this->kerjasama->where('token', $token)->find(),
            ];
        } elseif ($this->bhs_mahasiswa->where('token', $token)->find()) {
            $data = [
                'type' => "bhs_mahasiswa",
                'data' => $this->bhs_mahasiswa->where('token', $token)->find(),
            ];
        } elseif ($this->bhs_dosen->where('token', $token)->find()) {
            $data = [
                'type' => "bhs_dosen",
                'data' => $this->bhs_dosen->where('token', $token)->find(),
            ];
        } else {
            $data = $data;
        }

        return view('check', [
            "data" => $data
        ]);
    }
}
