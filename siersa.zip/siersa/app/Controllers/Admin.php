<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ModelKerjasama;
use App\Models\ModelBhsDosen;
use App\Models\ModelBhsMahasiswa;
use App\Models\UserModel;

class Admin extends BaseController
{
    protected $kerjasama;
    protected $bhs_mahasiswa;
    protected $bhs_dosen;
    protected $user;

    public function __construct()
    {
        $this->kerjasama = new ModelKerjasama();
        $this->user = new UserModel();
        $this->bhs_dosen = new ModelBhsDosen();
        $this->bhs_mahasiswa = new ModelBhsMahasiswa();
    }

    public function index()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        return view('admin/index', [
            'segment' => $this->request->uri->getSegments(),
            'user' => $this->user->findALl(),
            'bhs_dosen' => $this->bhs_dosen->findAll(),
            'bhs_mahasiswa' => $this->bhs_mahasiswa->findAll(),
            'kerjasama' => $this->kerjasama->findAll()
        ]);
    }

    public function kerjasama()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        return view('admin/kerjasama', [
            'segment' => $this->request->uri->getSegments(),
            'data' => $this->kerjasama->findAll()
        ]);
    }

    public function bhsmhs()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        return view('admin/bhsmhs', [
            'segment' => $this->request->uri->getSegments(),
            'data' => $this->bhs_mahasiswa->findAll()
        ]);
    }

    public function bhsdsn()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        return view('admin/bhsdsn', [
            'segment' => $this->request->uri->getSegments(),
            'data' => $this->bhs_dosen->findAll()
        ]);
    }

    public function users()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        return view('admin/users', [
            'segment' => $this->request->uri->getSegments(),
            'users' => $this->user->findAll()
        ]);
    }

    public function user_add()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        $data = [
            'name' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
            'token' => rand(10000000, 99999999)
        ];

        $this->user->save($data);

        return redirect()->to('/admin/users?pesan=berhasil');
    }

    public function user_update()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        $data = [
            'id' => $this->request->getPost('randomEdit'),
            'name' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
        ];

        if ($this->user->save($data)) {
            return redirect()->to('/admin/users?pesan=berhasil');
        } else {
            return redirect()->to('/admin/users?pesan=gagal');
        }
    }

    public function user_del($id = null)
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        if ($id == null) {
            return redirect()->to('/admin/users?pesan=gagal');
        } else {
            $this->user->delete($id);
            return redirect()->to('/admin/users?pesan=berhasil');
        }
    }

    public function kerjasama_update()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        $data = [
            'id'     => $this->request->getPost('randomEdit'),
            'status' => $this->request->getPost('status')
        ];

        if ($this->kerjasama->save($data)) {
            return redirect()->to('/admin/kerjasama?pesan=berhasil');
        } else {
            return redirect()->to('/admin/kerjasama?pesan=gagal');
        }
    }

    public function kerjasama_del($id = null)
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        if ($id == null) {
            return redirect()->to('/admin/kerjasama?pesan=gagal');
        } else {
            if ($this->kerjasama->delete($id)) {
                return redirect()->to('/admin/kerjasama?pesan=berhasil');
            } else {
                return redirect()->to('/admin/kerjasama?pesan=gagal');
            }
        }
    }

    public function bhsmhs_update()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        $file = $this->request->getFile('file_selesai');
        $file_name = $file->getRandomName();

        if ($this->request->getPost('status') == "REJECTED" || $this->request->getPost('status') == "PROSES") {
            $data = [
                'id'     => $this->request->getPost('randomEdit'),
                'status' => $this->request->getPost('status'),
            ];
        } else {
            $data = [
                'id'     => $this->request->getPost('randomEdit'),
                'status' => $this->request->getPost('status'),
                'file_selesai' => $file_name,
            ];
        }

        if ($this->bhs_mahasiswa->save($data)) {
            if ($data['status'] == "ACCEPTED") {
                $file->move(ROOTPATH . 'public/uploads/bhs_mahasiswa/', $file_name);
            }

            return redirect()->to('/admin/bhsmhs?pesan=berhasil');
        } else {
            return redirect()->to('/admin/bhsmhs?pesan=gagal');
        }
    }

    public function bhsmhs_del($id = null)
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        if ($id == null) {
            return redirect()->to('/admin/bhsmhs?pesan=gagal');
        } else {
            if ($this->bhs_mahasiswa->delete($id)) {
                return redirect()->to('/admin/bhsmhs?pesan=berhasil');
            } else {
                return redirect()->to('/admin/bhsmhs?pesan=gagal');
            }
        }
    }

    public function bhsdsn_update()
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        $file = $this->request->getFile('file_selesai');
        $file_name = $file->getRandomName();

        if ($this->request->getPost('status') == "REJECTED" || $this->request->getPost('status') == "PROSES") {
            $data = [
                'id'     => $this->request->getPost('randomEdit'),
                'status' => $this->request->getPost('status'),
            ];
        } else {
            $data = [
                'id'     => $this->request->getPost('randomEdit'),
                'status' => $this->request->getPost('status'),
                'file_selesai' => $file_name,
            ];
        }

        if ($this->bhs_dosen->save($data)) {
            if ($data['status'] == "ACCEPTED") {
                $file->move(ROOTPATH . 'public/uploads/bhs_dosen/', $file_name);
            }

            return redirect()->to('/admin/bhsdsn?pesan=berhasil');
        } else {
            return redirect()->to('/admin/bhsdsn?pesan=gagal');
        }
    }

    public function bhsdsn_del($id = null)
    {
        if (!isset($_COOKIE['token'])) {
            echo "TOKEN TIDAK ADA";
            return redirect()->to(base_url());
        } else {
            
            if ($this->user->where('token', $_COOKIE['token'])->find() == null) {
                return redirect()->to(base_url());
            }
        }

        if ($id == null) {
            return redirect()->to('/admin/bhsdsn?pesan=gagal');
        } else {
            if ($this->bhs_dosen->delete($id)) {
                return redirect()->to('/admin/bhsdsn?pesan=berhasil');
            } else {
                return redirect()->to('/admin/bhsdsn?pesan=gagal');
            }
        }
    }

    public function get($token)
    {        
        $data = null;
        if ($this->kerjasama->where('token', $token)->find()) {
            $data = [
                'type' => "kerjasama",
                'data' => $this->kerjasama->where('token', $token)->find(),
            ];
        } elseif ($this->bhs_mahasiswa->where('token', $token)->find()) {
            $data = [
                'type' => "bhs_mahasiswa",
                'data' => $this->bhs_mahasiswa->where('token', $token)->find(),
            ];
        } elseif ($this->bhs_dosen->where('token', $token)->find()) {
            $data = [
                'type' => "bhs_dosen",
                'data' => $this->bhs_dosen->where('token', $token)->find(),
            ];
        } else {
            $data = $data;
        }

        return json_encode($data);
    }

    public function get_user($token)
    {
        return json_encode($this->user->where('token', $token)->findAll()[0]);
    }
}
