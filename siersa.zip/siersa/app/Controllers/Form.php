<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ModelBhsDosen;
use App\Models\ModelKerjasama;
use App\Models\ModelBhsMahasiswa;

class Form extends BaseController
{
    protected $kerjasama;
    protected $bhs_mahasiswa;
    protected $bhs_dosen;

    public function __construct()
    {
        $this->kerjasama = new ModelKerjasama();
        $this->bhs_mahasiswa = new ModelBhsMahasiswa();
        $this->bhs_dosen = new ModelBhsDosen();
    }

    public function index()
    {
        return view('index');
    }

    public function kerjasama()
    {
        return view('kerjasama');
    }

    public function bahasa()
    {
        return view('bahasa');
    }

    public function bhsmahasiswa()
    {
        return view('bhsmahasiswa');
    }

    public function bhsdosen()
    {
        return view('bhsdosen');
    }

    public function token($tipe = null, $token = null)
    {
        if ($tipe !== 'failed') {
            return view('form_token', [
                'type' => $tipe,
                'token' => $token
            ]);
        } else {
            return view('form_token', [
                'type' => $tipe,
            ]);
        }
    }

    public function send()
    {
        $data = [
            'token' => rand(10000000000, 99999999999),
            'nama' => $this->request->getPost('nama'),
            'wa' => $this->request->getPost('wa'),
            'status' => "PROSES",
            'prodi' => $this->request->getPost('prodi'),
            'intuj' => $this->request->getPost('intuj'),
            'npintuj' => $this->request->getPost('npintuj'),
            'alamat' => $this->request->getPost('alamat'),
            'juker' => $this->request->getPost('juker'),
            'tuker' => $this->request->getPost('tuker'),
            'ruli' => $this->request->getPost('ruli'),
            'jawak' => $this->request->getPost('jawak'),
            'B64IMG' => $this->request->getPost('B64IMG'),
        ];

        // simpan data kedalam database
        if (!$this->kerjasama->save($data)) {
            return redirect()->to(base_url('/form/token/failed/' . $data['token']));
        }

        return redirect()->to(base_url('/form/token/success/' . $data['token']));
    }

    public function sendbm()
    {
        $file = $this->request->getFile('upfile');

        $data = [
            'token'        => rand(10000000000, 99999999999),
            'file'         => $file->getRandomName(),
            'file_selesai' => NULL,
            'status'       => "PROSES",
            'nama'         => $this->request->getPost('nama'),
            'nim'          => $this->request->getPost('nim'),
            'prodi'        => $this->request->getPost('prodi'),
            'wa'           => $this->request->getPost('wa'),
            'kdbhs'        => $this->request->getPost('kdbhs'),
            'ket'          => $this->request->getPost('ket'),
            'B64IMG'       => $this->request->getPost('B64IMG'),
        ];

        if ($this->bhs_mahasiswa->save($data)) {
            $file->move(ROOTPATH . 'public/uploads/bhs_mahasiswa/', $data['file'], true);

            return redirect()->to(base_url('/form/token/success/' . $data['token']));
        }

        return redirect()->to(base_url('/form/token/failed/'));
    }

    public function sendbd() 
    {
        $file = $this->request->getFile('upfile');

        $data = [
            'token'        => rand(10000000000, 99999999999),
            'file'         => $file->getRandomName(),
            'file_selesai' => NULL,
            'status'       => "PROSES",
            'nama'         => $this->request->getPost('nama'),
            'prodi'        => $this->request->getPost('prodi'),
            'wa'           => $this->request->getPost('wa'),
            'kdbhs'        => $this->request->getPost('kdbhs'),
            'ket'          => $this->request->getPost('ket'),
            'B64IMG'       => $this->request->getPost('B64IMG'),
        ];

        if ($this->bhs_dosen->save($data)) {
            $file->move(ROOTPATH . 'public/uploads/bhs_dosen/', $data['file'], true);

            return redirect()->to(base_url('/form/token/success/' . $data['token']));
        }

        return redirect()->to(base_url('/form/token/failed/'));
    }
}
