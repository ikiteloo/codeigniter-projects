<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class Auth extends BaseController
{
    protected $user;
    
    public function __construct()
    {
        $this->user = new UserModel();
    }

    public function index()
    {
        return redirect()->to(base_url());
    }

    public function u($token = null)
    {
        if ($token == null) {
            return redirect()->to(base_url());
        } else {
            $data = $this->user->where('token', $token)->find();
            if($data == null) {
                return redirect()->to(base_url('admin'));
            }
            setcookie('token', $data[0]['token'], time() + 10800, '/');
            setCookie('name', $data[0]['name'], time() + 10800, '/');
            return redirect()->to(base_url('admin'));
        }
    }

    public function out()
    {
        if (isset($_COOKIE['token'])) {
            setcookie('token', '', time() - 10800, '/');
            setcookie('name', '', time() - 10800, '/');
            return redirect()->to(base_url());
        } else {
            return redirect()->to(base_url());
        }
    }
}
