<?php

namespace App\Database\Seeds;

use App\Models\UserModel;
use CodeIgniter\Database\Seeder;

class UserSeed extends Seeder
{
    public function run()
    {
        $user = new UserModel();
        $user->insert([
            'id' => 478329,
            'name' => 'John Doe',
            'email' => 'fauzi@gmail.com',
            'token' => rand(10000000, 99999999),
        ]);
    }
}
