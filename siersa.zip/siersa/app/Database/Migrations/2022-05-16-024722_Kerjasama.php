<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Kerjasama extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'token' => [
                'type'      => 'VARCHAR',
                'constraint' => '255',
            ],
            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'wa' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'prodi' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'intuj' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'npintuj' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'alamat' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'juker' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'tuker' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'ruli' => [
                'type'       => 'TEXT',
            ],
            'jawak' => [
                'type'       => 'INT',
                'constraint' => 11,
            ],
            'B64IMG' => [
                'type'       => 'TEXT',
            ],
            'created_at' => [
                'type'       => 'DATETIME',
            ],
            'updated_at' => [
                'type'       => 'DATETIME',
            ],
            'deleted_at' => [
                'type'       => 'DATETIME',
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('kerjasama', true);
    }

    public function down()
    {
        $this->forge->dropTable('kerjasama', true);
    }
}
