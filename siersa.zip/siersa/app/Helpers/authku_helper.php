<?php
    function setCook($token) {
        return set_cookie('token', $token, 10800, '/');
    }

    function getCook() {
        return get_cookie('token');
    }
