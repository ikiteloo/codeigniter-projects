<?= $this->extend('pages_template'); ?>
<?= $this->section('content'); ?>
<div class="container mt-5">
    <div class="card card-body">
        <?php if ($data == null) : ?>
            <div class="alert alert-danger">
                <h1>Data sesuai dengan token tidak dapat ditemukan</h1>
            </div>
        <?php else : ?>
            <div class="text-center">
                <div class="text-muted"><span>Token Pengajuan</span></div>
                <h2><kbd><?= $token ?></kbd></h2>
            </div>
            <div class="<?= $ua->isMobile() == false ? 'mx-5' : '' ?>" style="margin-top: 50px;">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-4">
                            <h5>Detail Pengajuan</h5>
                            <table class="table table-bordered table-hover">
                                <tbody>
                                    <tr>
                                        <th width=30%>Status</th>
                                        <td><?= $data->status ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Token</th>
                                        <td><?= $data->token ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Nomor Dokumen</th>
                                        <td>-</td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Berlaku Tanggal</th>
                                        <td>-</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="mb-4">
                            <h5>Detail Pengirim</h5>
                            <table class="table table-bordered table-hover">
                                <tbody>
                                    <tr>
                                        <th width=30%>Nama</th>
                                        <td><?= $data->status ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Jabatan</th>
                                        <td><?= $data->jabatan ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Lembaga / Biro / Unit / Fakultas / Prodi</th>
                                        <td><?= $data->lembaga ?></td>
                                    </tr>
                                    <!-- <tr>
                                        <th width=30%>Fakultas</th>
                                        <td><? // echo $data->token 
                                            ?></td>
                                    </tr> -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-4">
                            <h5>Detail Pengajuan</h5>
                            <table class="table table-bordered table-hover">
                                <tbody>
                                    <tr>
                                        <th width=30%>Nama Dokuman</th>
                                        <td><?= $data->nama_dokumen ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Revisi Ke</th>
                                        <td>
                                            <?php if ($data->revisi == "lainnya") : ?>
                                                <?= $data->revisi_manual ?>
                                            <?php else : ?>
                                                <?= $data->revisi ?>
                                            <?php endif ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Tanggal</th>
                                        <td><?= $data->tanggal ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Halaman</th>
                                        <td><?= $data->halaman ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Paragraf</th>
                                        <td><?= $data->paragraf ?></td>
                                    </tr>
                                    <tr>
                                        <th width=30%>Rasional</th>
                                        <td><?= $data->rasional ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <?php if ($data->validasi_dokumen !== null) : ?>
                            <div class="mb-4 p-4 rounded" style="background-color: darkseagreen;">
                                <h5>Dokumen Tervalidasi</h5>
                                <table class="table table-bordered table-hover">
                                    <tbody>
                                        <tr>
                                            <th width=30%>Dokumen Tervalidasi</th>
                                            <td>
                                                <a href="/assets/validasi/<?= $data->validasi_dokumen ?>" target="_blank" rel="noopener noreferrer"><?= $data->validasi_dokumen ?></a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif ?>

                        <?php if ($data->status == "selesai") : ?>
                            <div class="mb-4 p-4 rounded" style="background-color: lightgreen;">
                                <h5>Validasi Selesai</h5>
                                <table class="table table-bordered table-hover">
                                    <tbody>
                                        <tr>
                                            <th width=30%>Validasi Selesai</th>
                                            <td><?= $data->validasi ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif ?>
                    </div>
                </div>
            </div>
            <div class="<?= $ua->isMobile() == false ? 'mx-5' : '' ?> mt-4">
                <button type="button" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#addValidasi">Validasi Dokumen</button>
                <a href="/page/cetak/<?= $token ?>" class="btn btn-dark px-4">Print Dokumen</a>
            </div>
        <?php endif ?>
    </div>
</div>

<!-- Modal Validasi Dokumen -->
<div class="modal fade" id="addValidasi" tabindex="-1" aria-labelledby="addValidasiLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginLabel">Tambah Validasi Dokumen</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <b>Perhatian!</b>
                    <br> Validasi dokumen adalah surat yang telah anda <kbd><a href="/page/cetak/<?= $token ?>" target="_blank" class="text-white">Print</a></kbd> dan mendapatkan <strong>Tanda Tangan</strong> dari <strong>Pimpinan</strong>
                </div>
                <form action="/pengajuan/avd" enctype="multipart/form-data" method="post">
                    <input type="hidden" name="randomEdit" id="randomEdit" value="<?= $data->id ?>" class="form-control">
                    <input type="hidden" name="token" value="<?= $data->token ?>" class="form-control">
                    <div class="form-group mb-3">
                        <label for="validasi" class="form-label">validasi</label>
                        <input type="file" name="validasi" id="validasi" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-dark">SIMPAN</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>